/*
 * Author: Daniel Gregory
 * Date: 3/26/24
 * CS 216 Lab 8
 */
#include "card.h"
#include <iostream>

// Default constructor
Card::Card() : suit(0), point(0) {}

// Alternate constructor
Card::Card(cSuits s, cPoints p) : suit(s), point(p) {}

// Get the point value of the card
Card::cPoints Card::getPoint() const {
    return point;
}

// Get the suit value of the card
Card::cSuits Card::getSuit() const {
    return suit;
}

// Define the less than operator for Card class
bool operator<(Card C1, Card C2) {
    return C1.point < C2.point;
}
ostream& operator<<(ostream& out, const Card& C) {
    // Get the symbol for the card's suit from the SUITS map
    string suitSymbol = SUITS.at(C.getSuit());

    // Get the point value of the card
    int point = C.getPoint();

    // Convert point values to string representation
    string pointStr;
    switch (point) {
        case 11:
            pointStr = "J"; // Jack
            break;
        case 12:
            pointStr = "Q"; // Queen
            break;
        case 13:
            pointStr = "K"; // King
            break;
        case 14:
            pointStr = "A"; // Ace
            break;
        default:
            // For other point values, convert them to string representation
            pointStr = to_string(point);
            break;
    }

    // Output the suit symbol, point value, and suit symbol again
    out << suitSymbol << pointStr << suitSymbol;

    return out;
}


// Define a static function to compare two Card objects
bool Card::HigherBefore(const Card& C1, const Card& C2) {
    return C1.point >= C2.point;
}

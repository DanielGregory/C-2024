#include <iostream>
#include <vector>
#include <algorithm>
#include <random> // For random_device, default_random_engine, shuffle
#include "card.h"
#include "pokerhand.h"
#include "deck.h"
#include "rank.h"

using namespace std;

const int TOTALCARDS = 7;  // Each player gets TOTALCARDS=7 cards
const int HANDS = 5;       // Each player plays HANDS=5 cards in hand

// Function to decide the best five cards out of seven cards
// Best means the highest ranking of five-card poker hand defined in the poker game
// Pass in a vector of seven cards 
// (const call by reference: safe for the argument and no copy is made for efficiency)
// Return the best PokerHand object which represents the best five-card poker hand
PokerHand best_FIVE_out_of_SEVEN(const vector<Card>& cards) {
    PokerHand bestH;
    PokerHand cardsH;

    // Check if the parameter is valid
    if (cards.size() != TOTALCARDS) {
        cout << "Invalid Cards, we need SEVEN cards!" << endl;
        return cardsH; // Return a PokerHand object by default constructor
    }

    // Consider all possible ways of dropping two cards from all seven cards 
    // i is the index of the first card dropped
    // and j is the index of the second card dropped.
    // There are 21 different ways to pick 5 cards out of 7
    for (int i = 0; i < TOTALCARDS; i++) {
        for (int j = i + 1; j < TOTALCARDS; j++) {
            Card pick[HANDS];
            int index = 0;

            // Iterate over all seven cards and assign them to the pick[] array
            // Exclude cards with index numbers of #i and #j.
            for (int k = 0; k < TOTALCARDS; k++) {
                if (k == i || k == j)
                    continue;
                pick[index] = cards[k];
                index++;
            }

            // Create a PokerHand with pick[]
            cardsH.setPokerHand(pick, HANDS);

            // Check to see if current pick is better than the best you have seen so far
            if (bestH.compareHand(cardsH) < 0) {
                bestH = cardsH;
            }
        }
    }

    return bestH;
}

int main() {
    // Initialize a deck and shuffle it
    Deck deck;
    deck.createDeck();
    deck.shuffleDeck();

    // Deal cards to players and community cards
    vector<Card> player1Hand, player2Hand, communityCards;
    for (int i = 0; i < 2; ++i) {
        player1Hand.push_back(deck.deal_a_card());
        player2Hand.push_back(deck.deal_a_card());
    }
    for (int i = 0; i < 5; ++i) {
        Card communityCard = deck.deal_a_card();
    communityCards.push_back(communityCard);
    player1Hand.push_back(communityCard);
    player2Hand.push_back(communityCard);
    }

    // Print initial information
    cout << "********************************************************" << endl;
    cout << "* Texas Hold'em is one popular poker played worldwide *" << endl;
    cout << "* Texas Hold'em is usually played with 2 to 10 players *" << endl;
    cout << "* The game involves a standard 52-card deck *" << endl;
    cout << "* Texas Hold'em combines elements of skill and luck *" << endl;
    cout << "* making it a challenging and exciting game *" << endl;
    cout << "* enjoyed by players of all skill levels. *" << endl;
    cout << "* The 2-player Poker game is written by Yi Pike *" << endl;
    cout << "* Try to beat the computer with five-card poker hand *" << endl;
    cout << "********************************************************" << endl<<endl;

    cout << "The cards in your hand are:" << endl;
    cout << player1Hand[0] << endl << "    " << player1Hand[1] << endl<< endl;

    cout << "The FIVE cards on the deck to share are:" << endl;
    cout << "*************************" << endl;
    for (const auto& card : communityCards) {
        cout << "*  " << card << "          *" << endl;
    }
    cout << "*************************" << endl;

    cout << "The cards in computer's hand are:" << endl;
    cout << player2Hand[0] << endl << "    " << player2Hand[1] << endl<< endl;

    // Determine the best hand for each player and the community
    PokerHand player1BestHand = best_FIVE_out_of_SEVEN(player1Hand);
    PokerHand player2BestHand = best_FIVE_out_of_SEVEN(player2Hand);

    // Print the best hands for each player
    cout << "Player 1: You" << endl;
    cout << "*** Best five-card hand ***" << endl;
    player1BestHand.print();
    cout << endl << endl;
    cout << "Player 2: Computer" << endl;
    cout << "*** Best five-card hand ***" << endl;
    player2BestHand.print();
    cout << endl << endl;

    // Compare hands and declare the winner
    int result = player1BestHand.compareHand(player2BestHand);
    if (result > 0) {
        cout << "Congratulations, you win the game!" << endl;
    } else if (result < 0) {
        cout << "Sorry, you lose the game!" << endl;
    } else {
        cout << "It's a tie!" << endl;
    }
    cout << endl;
    cout << "Do you want to play poker game again (Press \"q\" or \"Q\" to quit the program) ";
    char choice;
    cin >> choice;
    if (choice == 'q' || choice == 'Q') {
        cout << "Thank you for using this program!" << endl;
        return 0;
    } else {
        main(); // Restart the game
    }
}

/*
 * Author: Daniel Gregory
 * Date: 3/26/24
 * CS 216 Lab 8 part 2
 */
#include "deck.h"
#include <iostream>
#include <algorithm>
#include <random>

using namespace std;
//creates deck
void Deck::createDeck() {
    deck.clear();
    
    for (int suit = CARD_START; suit <= SUITSTYPE; ++suit) {
        for (int point = CARD_START; point <= POINTS; ++point) {
            deck.push_back(Card(static_cast<Card::cSuits>(suit), static_cast<Card::cPoints>(point)));
        }
    }
}
//shuffle deck function
void Deck::shuffleDeck() {
    random_device rd;
    default_random_engine rng(rd());
    shuffle(deck.begin(), deck.end(), rng);
}

Card Deck::deal_a_card() {
    if (deck.empty()) {
        // Handle the case when the deck is empty
        // For simplicity, return an invalid card
        cerr << "The deck is empty." << endl;
        return Card(0, 0);
    }
    
    Card dealtCard = deck.back();
    deck.pop_back();
    return dealtCard;
}

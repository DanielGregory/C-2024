#include "pokerhand.h"
#include "rank.h"
#include "card.h"
#include <algorithm>
#include <iostream>

using namespace std;

PokerHand::PokerHand() {
    // Initialize hand_rank to default values
    hand_rank.kind = Rank::hRanks::NoRank;
    hand_rank.point = 0;
}

void PokerHand::setPokerHand(Card in_hand[], int size) {
    if (size != HANDS) {
        cout << "Invalid number of cards!" << endl;
        return;
    }

    // Copy the cards from the input array to the class member array
    for (int i = 0; i < HANDS; ++i) {
        cards[i] = in_hand[i];
    }
    // Sort the hand
    sort();

    // Evaluate the hand and determine its rank
    if (isStraightFlush()) {
        hand_rank.kind = Rank::hRanks::StraightFlush;
        hand_rank.point = cards[0].getPoint(); // Highest point of the sequential five cards
    } else if (isFourOfAKind()) {
        hand_rank.kind = Rank::hRanks::FourOfAKind;
        hand_rank.point = cards[2].getPoint(); // Highest point of the same four cards
    } else if (isFullHouse()) {
        hand_rank.kind = Rank::hRanks::FullHouse;
        hand_rank.point = cards[2].getPoint(); // Highest point of the same three cards
    } else if (isFlush()) {
        hand_rank.kind = Rank::hRanks::Flush;
        hand_rank.point = cards[0].getPoint(); // Highest point of the five cards
    } else if (isStraight()) {
        hand_rank.kind = Rank::hRanks::Straight;
        hand_rank.point = cards[0].getPoint(); // Highest point of the sequential five cards
    } else if (isThreeOfAKind()) {
        hand_rank.kind = Rank::hRanks::ThreeOfAKind;
        hand_rank.point = cards[2].getPoint(); // Highest point of the same three cards
    } else if (isPair()) {
        hand_rank.kind = Rank::hRanks::Pair;
        // Find the point of the pair
    for (int i = 0; i < HANDS - 1; ++i) {
        if (cards[i].getPoint() == cards[i + 1].getPoint()) {
            hand_rank.point = cards[i].getPoint();
            break; // Exit the loop once the pair is found
    }}} else {
        hand_rank.kind = Rank::hRanks::HighCard;
        hand_rank.point = cards[0].getPoint(); // Highest point of the five cards
    }
}

int PokerHand::compareHand(const PokerHand &otherHand) const {
    // Implement the logic to compare two poker hands and return the result
    if (hand_rank.kind < otherHand.hand_rank.kind) {
        return -1; // This hand loses to the otherHand
    } else if (hand_rank.kind > otherHand.hand_rank.kind) {
        return 1; // This hand beats the otherHand
    } else {
        // If the ranks are the same, compare the values of the ranks
        if (hand_rank.point < otherHand.hand_rank.point) {
            return -1; // This hand loses to the otherHand
        } else if (hand_rank.point > otherHand.hand_rank.point) {
            return 1; // This hand beats the otherHand
        } else {
            return 0; // It's a tie
        }
    }
}

void PokerHand::print() const {
    // Print out the five cards and its rank to standard output
    cout << "Five cards in order:" << endl;
    for (int i = 0; i < HANDS; ++i) {
        cout << cards[i] << " ";
    }
    cout << endl;
    cout << "Its rank is: ";
    hand_rank.print();
}

Rank PokerHand::getRank() const {
    return hand_rank;
}

bool PokerHand::isStraightFlush() {
    // Implement logic to determine if the hand is a straight flush
    if (isAllOneSuit() && isSequence()) {
        return true;
    }
    return false;
}

bool PokerHand::isFourOfAKind() {
    // Implement logic to determine if the hand is a four of a kind
    for (int i = 0; i < HANDS - 3; ++i) {
        if (cards[i].getPoint() == cards[i + 1].getPoint() &&
            cards[i].getPoint() == cards[i + 2].getPoint() &&
            cards[i].getPoint() == cards[i + 3].getPoint()) {
            return true;
        }
    }
    return false;
}

bool PokerHand::isFullHouse() {
    // Implement logic to determine if the hand is a full house
    if ((cards[0].getPoint() == cards[1].getPoint() && cards[1].getPoint() == cards[2].getPoint() &&
         cards[3].getPoint() == cards[4].getPoint()) ||
        (cards[0].getPoint() == cards[1].getPoint() &&
         cards[2].getPoint() == cards[3].getPoint() && cards[3].getPoint() == cards[4].getPoint())) {
        return true;
    }
    return false;
}

bool PokerHand::isFlush() {
    // Implement logic to determine if the hand is a flush
    if (isAllOneSuit()) {
        return true;
    }
    return false;
}

bool PokerHand::isStraight() {
    // Implement logic to determine if the hand is a straight
    if (isSequence()) {
        return true;
    }
    return false;
}

bool PokerHand::isThreeOfAKind() {
    // Implement logic to determine if the hand is a three of a kind
    for (int i = 0; i < HANDS - 2; ++i) {
        if (cards[i].getPoint() == cards[i + 1].getPoint() &&
            cards[i].getPoint() == cards[i + 2].getPoint()) {
            return true;
        }
    }
    return false;
}

bool PokerHand::isPair() {
    // Implement logic to determine if the hand is a pair
    for (int i = 0; i < HANDS - 1; ++i) {
        if (cards[i].getPoint() == cards[i + 1].getPoint()) {
            return true;
        }
    }
    return false;
}

bool PokerHand::isHighCard() {
    // Implement logic to determine if the hand is a high card
    return !isPair() && !isThreeOfAKind() && !isStraight() && !isFlush() && !isFullHouse() && !isFourOfAKind() && !isStraightFlush();
}


void PokerHand::sort() {
    // Implement sorting algorithm to sort the cards in decreasing order by card points
    std::sort(cards, cards + HANDS, [](const Card &a, const Card &b) {
        return a.getPoint() > b.getPoint();
    });
}

bool PokerHand::isAllOneSuit() const {
    // Implement logic to check if all cards are of the same suit
    for (int i = 1; i < HANDS; ++i) {
        if (cards[i].getSuit() != cards[0].getSuit()) {
            return false;
        }
    }
    return true;
}

bool PokerHand::isSequence() const {
    // Implement logic to check if the cards form a continuous sequence
    for (int i = 0; i < HANDS - 1; ++i) {
        if (cards[i].getPoint() - 1 != cards[i + 1].getPoint()) {
            return false;
        }
    }
    return true;
}


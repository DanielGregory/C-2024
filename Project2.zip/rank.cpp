/* File: rank.cpp
 * Course: CS216-00x
 * Project: Lab 9 (as part of Project 2)
 * Purpose: the implementation of member functions for the Rank class.
 *
 */
#include <iostream>
#include <sstream>
#include <iomanip>
#include "rank.h"

using namespace std;

// Default constructor.
Rank::Rank()
{
}

// Alternate constructor.
// Create a Rank object with specified ranking name and points.
Rank::Rank(hRanks r, rPoints p)
    :kind(r), point(p)
{
}

// access the hand ranking kind
Rank::hRanks Rank::getKind() const
{
    return kind;
}

// access the card point value of the corresponding ranking kind
Rank::rPoints Rank::getPoint() const
{
    return point;
}

// Display a description of the hand-ranking category to the standard output.
// The format should be:
//   the corresponding ranking kind followed by the point in ( )
//   for example, assume the ranking kind is "FullHouse" and the point is 11:
//   FullHouse( J)
void Rank::print() const
{
    switch (kind) {
        case hRanks::NoRank:
            cout << "NoRank";
            break;
        case hRanks::HighCard:
            cout << "HighCard";
            break;
        case hRanks::Pair:
            cout << "Pair";
            break;
        case hRanks::ThreeOfAKind:
            cout << "ThreeOfAKind";
            break;
        case hRanks::Straight:
            cout << "Straight";
            break;
        case hRanks::Flush:
            cout << "Flush";
            break;
        case hRanks::FullHouse:
            cout << "FullHouse";
            break;
        case hRanks::FourOfAKind:
            cout << "FourOfAKind";
            break;
        case hRanks::StraightFlush:
            cout << "StraightFlush";
            break;
    }
      // If the point is a high card value, print the corresponding card kind
    if (point >= 11 && point <= 14) {
        string card_kind;
        switch (point) {
            case 11:
                card_kind = "J";
                break;
            case 12:
                card_kind = "Q";
                break;
            case 13:
                card_kind = "K";
                break;
            case 14:
                card_kind = "A";
                break;
        }
        cout << "(" << card_kind << ")";
    } else {
        cout << "(" << point << ")";
    }
    cout << endl;
}
